package Sim;

// This class is used to schedule timer events when for instance calling the 
// recv method in SimEnt classes due to other reasons than that a message has
// arrived.

public class TimerEvent implements Event{
	public void entering(SimEnt locale)
	{
	}
}
